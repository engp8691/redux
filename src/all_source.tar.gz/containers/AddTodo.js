import React from 'react'
import { connect } from 'react-redux'
import { addTodo } from '../actions'

const mapStateToProps = function(state, ownProps) {
	return {...state, ...ownProps}
}

const AddTodo = (props) => {
	let dispatch = props.dispatch;

	let textInput;

	return (
		<div>
			<form onSubmit={(e) => {
				e.preventDefault();

				if (!textInput.value.trim()) {
					return
				}
				dispatch(addTodo(textInput.value));
				textInput.value = ''
			}}>

			<input type="text" ref={element=>textInput=element} />
			<button type="submit">
				Add Todo
			</button>
			</form>
		</div>
	)
}

// AddTodo is a container component, connect it to the Redux store.
export default connect(mapStateToProps)(AddTodo)

